package com.ecommerce.test;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class FileUploadUsingAutoITDemo {

	public static void main(String[] args) throws InterruptedException, IOException {

		WebDriver driver = new ChromeDriver(); // new FirefoxDriver();
		demoFileUpload(driver);
		
		//driver.close();
	}
	
	static void demoFileUpload(WebDriver driver) throws InterruptedException, IOException {

		Actions actions = new Actions(driver);
	    
		driver.get("https://demoqa.com/automation-practice-form");
	    
	    Thread.sleep(1000);
	    
	    WebElement btn = driver.findElement(By.id("uploadPicture"));
	    
	    actions.click(btn).perform();

	    //driver.findElement(By.cssSelector("#uploadPicture")).click();
	    
	    Thread.sleep(1000);
	    
	    Runtime.getRuntime().exec("G:/tmp/myscreenshot.exe");
	    
	    //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
	}
}