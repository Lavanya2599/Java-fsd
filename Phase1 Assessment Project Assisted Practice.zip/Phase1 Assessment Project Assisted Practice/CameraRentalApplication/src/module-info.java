/**
 * 
 */
/**
 * @author home
 *
 */
module CameraRentalApplication {
}