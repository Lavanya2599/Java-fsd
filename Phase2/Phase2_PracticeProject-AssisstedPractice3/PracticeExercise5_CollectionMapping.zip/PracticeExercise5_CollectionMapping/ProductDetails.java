package com.simpli;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.*;
import javax.xml.bind.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ecommerce.Color;
import com.ecommerce.EProduct;
import com.ecommerce.Finance;
import com.simpli.HibernateUtil;
import com.ecommerce.OS;
import com.ecommerce.ScreenSizes;

@WebServlet("/details")
public class ProductDetails extends HttpServlet {
        private static final long serialVersionUID = 1L;

	    public ProductDetails() {
	        super();
	        
	    }

	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        // TODO Auto-generated method stub
	        try {
	            SessionFactory factory = HibernateUtil.getSessionFactory();                        
	            Session session = factory.openSession();                                                 
	            List<EProduct> list = session.createQuery("from EProduct").list();

	            PrintWriter out = response.getWriter();
	            out.println("<html><body>");
	            out.println("<b>Product Listing</b><br>");
	            out.println("<table border='1'>"); // Add table border attribute

	            // Table headers
	            out.println("<tr>");
	            out.println("<th>ID</th>");
	            out.println("<th>Name</th>");
	            out.println("<th>Price</th>");
	            out.println("<th>Date Added</th>");
	            out.println("<th>Finance</th>");
	            out.println("<th>Color</th>");
	            out.println("<th>OS</th>");
	            out.println("<th>Screen Sizes</th>");
	            out.println("</tr>");

	            for(EProduct p: list) {
	                out.println("<tr>");
	                out.println("<td>" + String.valueOf(p.getID()) + "</td>");
	                out.println("<td>" + p.getName() + "</td>");
	                out.println("<td>" + String.valueOf(p.getPrice()) + "</td>");
	                out.println("<td>" + p.getDateAdded().toString() + "</td>");

	                // Finance
	                Map finances = p.getFinance();
	                out.println("<td>");
	                if (finances.get("CREDITCARD") != null) {
	                    Finance f = (Finance) finances.get("CREDITCARD");
	                    out.println(f.getName() + " &nbsp;");
	                }
	                if (finances.get("BANK") != null) {
	                    Finance f = (Finance) finances.get("BANK");
	                    out.println(f.getName() + " &nbsp;");
	                }
	                out.println("</td>");

	                // Color
	                List<Color> colors = p.getColors();
	                out.println("<td>");
	                for(Color c: colors) {
	                    out.print(c.getName() + "&nbsp;");
	                }
	                out.println("</td>");

	                // OS
	                Set<OS> os= p.getOs();
	                out.println("<td>");
	                for(OS o: os) {
	                    out.print(o.getName() + "&nbsp;");
	                }
	                out.println("</td>");

	                // Screen Sizes
	                Collection<ScreenSizes> sizes= p.getScreensizes();
	                out.println("<td>");
	                for(ScreenSizes s: sizes) {
	                    out.print(s.getSize() + "&nbsp;");
	                }
	                out.println("</td>");

	                out.println("</tr>");
	            }

	            session.close();

	            out.println("</table>"); // Close the table tag
	            out.println("</body></html>");

	        } catch (Exception ex) {
	            throw ex;
	        }
	    }
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	         // TODO Auto-generated method stub
	         doGet(request, response);
	 }

}
