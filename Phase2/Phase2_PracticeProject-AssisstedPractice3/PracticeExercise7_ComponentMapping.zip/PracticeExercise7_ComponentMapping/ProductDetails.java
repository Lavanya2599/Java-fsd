package com.simpli;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.*;
import javax.xml.bind.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.ecommerce.EProduct;
import com.simpli.HibernateUtil;
import com.ecommerce.ProductParts;


/**
* Servlet implementation class ProductDetails
*/
@WebServlet("/details")
public class ProductDetails extends HttpServlet {
        private static final long serialVersionUID = 1L;
       
        
        
    /**
* @see HttpServlet#HttpServlet()
*/
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

        /**
         * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
         */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            SessionFactory factory = HibernateUtil.getSessionFactory();
            Session session = factory.openSession();

            List<EProduct> list = session.createQuery("from EProduct").list();
            PrintWriter out = response.getWriter();

            out.println("<html><body>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>ID</th><th>Name</th><th>Price</th><th>Date Added</th><th>CPU</th><th>HDD</th><th>RAM</th></tr>");

            for (EProduct p : list) {
                out.println("<tr>");
                out.println("<td>" + String.valueOf(p.getID()) + "</td>");
                out.println("<td>" + p.getName() + "</td>");
                out.println("<td>" + String.valueOf(p.getPrice()) + "</td>");
                out.println("<td>" + p.getDateAdded().toString() + "</td>");

                ProductParts parts = p.getParts();
                out.println("<td>" + parts.getCpu() + "</td>");
                out.println("<td>" + parts.getHdd() + "</td>");
                out.println("<td>" + parts.getRam() + "</td>");

                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            session.close();
        } catch (Exception ex) {
            throw ex;
        }
    }


       /**
        * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
        */
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
               // TODO Auto-generated method stub
               doGet(request, response);
       }

}