package com.ecommerce.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.ecommerce.beans.CustomEventPublisher;
@Controller
public class MainController {

    @Autowired
    private CustomEventPublisher customEventPublisher;

    @RequestMapping(value = "/customevent", method = RequestMethod.GET)
    public String customEvent(ModelMap map) {
        customEventPublisher.publish();
        customEventPublisher.publish();
        return "customEvent";
    }
}
