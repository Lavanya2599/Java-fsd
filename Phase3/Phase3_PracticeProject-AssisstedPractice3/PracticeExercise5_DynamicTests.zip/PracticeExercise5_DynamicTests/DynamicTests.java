package com.ecommerce.tests;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.Collection;

@DisplayName("JUnit 5 Dynamic Tests Example")
public class DynamicTests {

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                dynamicTest("simple dynamic test", () -> Assertions.assertTrue(true)),
                dynamicTest("My Executable Class", new MyExecutable()),
                dynamicTest("Exception Executable", () -> {
                    try {
                        throw new Exception("Exception Example");
                    } catch (Exception e) {
                        // Handle the exception as desired
                        System.out.println("Exception occurred: " + e.getMessage());
                    }
                }),
                dynamicTest("simple dynamic test-2", () -> Assertions.assertTrue(true))
        );
    }

    private DynamicTest dynamicTest(String displayName, Executable executable) {
        return DynamicTest.dynamicTest(displayName, executable);
    }
}

class MyExecutable implements Executable {

    @Override
    public void execute() throws Throwable {
        System.out.println("Hello World!");
    }
}
