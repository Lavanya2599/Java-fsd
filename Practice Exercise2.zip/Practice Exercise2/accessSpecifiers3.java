package package2;

import practiceproject1.*;

public class accessSpecifiers3 extends protectedAccessspecifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		accessSpecifiers3 obj = new accessSpecifiers3 ();   
	    obj.display();  
	}
}
