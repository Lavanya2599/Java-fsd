package package2;

import practiceproject1.*;

public class accessSpecifiers4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		publicAccessspecifiers obj = new publicAccessspecifiers(); 
        obj.display();  
	}
}
