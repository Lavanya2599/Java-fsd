package practiceproject1;

//4. using public access specifiers

public class publicAccessspecifiers {
	public void display() { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}
