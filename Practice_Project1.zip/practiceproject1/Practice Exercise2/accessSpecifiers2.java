package practiceproject1;

//2. using private access specifiers
class privateaccessspecifier { 
	private void display() { 
      System.out.println("You are using private access specifier"); 
  } 
} 

public class accessSpecifiers2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//private
		System.out.println("Private Access Specifier");
		privateaccessspecifier  obj = new privateaccessspecifier();

	}

}
